package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    // Kendi HTTPS sunucu adresini buraya yaz.
    private static final String API_URL = "https://YOUR-SERVER.example.com/api/chat";
    private static final int MIC_PERMISSION = 100;
    private static final int SPEECH_REQUEST = 101;

    private LinearLayout messages;
    private ScrollView scroll;
    private EditText input;
    private TextView status;
    private TextToSpeech tts;
    private SharedPreferences prefs;
    private JSONArray history = new JSONArray();
    private boolean speakReplies = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);
        try { history = new JSONArray(prefs.getString("history", "[]")); }
        catch (Exception ignored) { history = new JSONArray(); }
        buildUi();
        tts = new TextToSpeech(this, this);
        if (history.length() == 0) addMessage("JARVIS", "Sistem hazır. Size nasıl yardımcı olabilirim?");
        else restoreHistory();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(12));
        page.setBackgroundColor(Color.rgb(8, 13, 24));

        TextView title = new TextView(this);
        title.setText("J A R V I S");
        title.setTextColor(Color.rgb(90, 210, 255));
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        status = new TextView(this);
        status.setText("PERSONAL AI SYSTEM  •  ONLINE");
        status.setTextColor(Color.rgb(125, 155, 180));
        status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        page.addView(status, new LinearLayout.LayoutParams(-1, dp(25)));

        // Iron Man-inspired JARVIS holographic HUD (original interface artwork).
        HudView hud = new HudView(this);
        page.addView(hud, new LinearLayout.LayoutParams(-1, dp(142)));

        scroll = new ScrollView(this);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(messages);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        addQuickButton(quick, "Saat", "Saat kaç?");
        addQuickButton(quick, "Ayarlar", "Telefon ayarlarını aç");
        addQuickButton(quick, "Temizle", "__CLEAR__");
        page.addView(quick);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setHint("JARVIS'e mesaj yaz...");
        input.setTextSize(15);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setBackgroundColor(Color.rgb(25, 35, 51));
        bar.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1));

        Button mic = makeButton("MIC");
        mic.setOnClickListener(v -> startVoice());
        bar.addView(mic, new LinearLayout.LayoutParams(dp(58), dp(48)));

        Button send = makeButton("GÖNDER");
        send.setOnClickListener(v -> sendMessage());
        bar.addView(send, new LinearLayout.LayoutParams(dp(82), dp(48)));
        page.addView(bar, new LinearLayout.LayoutParams(-1, dp(58)));
        setContentView(page);
    }


    private class HudView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int cyan = Color.rgb(53, 202, 255);
        HudView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(getWidth() * 0.31f, getHeight() * 0.43f);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
            p.setColor(cyan); p.setShadowLayer(dp(7), 0, 0, cyan);
            c.drawCircle(cx, cy, r, p);
            p.setShadowLayer(0, 0, 0, 0); p.setStrokeWidth(dp(2));
            c.drawCircle(cx, cy, r * .78f, p);
            p.setStrokeWidth(dp(1));
            c.drawCircle(cx, cy, r * .57f, p);
            RectF arc = new RectF(cx-r*1.12f, cy-r*1.12f, cx+r*1.12f, cy+r*1.12f);
            p.setStrokeWidth(dp(3));
            c.drawArc(arc, 205, 92, false, p);
            c.drawArc(arc, 25, 92, false, p);
            p.setStrokeWidth(dp(1));
            for (int i=0; i<48; i++) {
                double a = Math.PI * 2 * i / 48.0;
                float x1 = cx + (float)Math.cos(a) * r * .88f;
                float y1 = cy + (float)Math.sin(a) * r * .88f;
                float x2 = cx + (float)Math.cos(a) * r * (i % 4 == 0 ? 1.12f : 1.04f);
                float y2 = cy + (float)Math.sin(a) * r * (i % 4 == 0 ? 1.12f : 1.04f);
                c.drawLine(x1,y1,x2,y2,p);
            }
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(13));
            p.setColor(Color.WHITE); c.drawText("J.A.R.V.I.S", cx, cy+dp(4), p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(dp(7));
            p.setColor(cyan); c.drawText("NEURAL INTERFACE  /  ONLINE", cx, cy+r+dp(19), p);
            p.setTextAlign(Paint.Align.LEFT); p.setTextSize(dp(7));
            c.drawText("SYS 01", dp(5), dp(17), p);
            p.setTextAlign(Paint.Align.RIGHT); c.drawText("HUD ACTIVE", getWidth()-dp(5), dp(17), p);
        }
    }

    private void addQuickButton(LinearLayout row, String label, String command) {
        Button b = makeButton(label);
        b.setTextSize(11);
        b.setOnClickListener(v -> {
            if ("__CLEAR__".equals(command)) clearChat();
            else { input.setText(command); sendMessage(); }
        });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(40), 1));
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(110, 220, 255));
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24, 48, 68)));
        return b;
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void addMessage(String who, String text) {
        TextView bubble = new TextView(this);
        bubble.setText(who + "\n" + text);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(15);
        bubble.setPadding(dp(14), dp(11), dp(14), dp(11));
        bubble.setBackgroundColor("JARVIS".equals(who) ? Color.rgb(22, 43, 61) : Color.rgb(34, 57, 75));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        messages.addView(bubble, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void restoreHistory() {
        for (int i = 0; i < history.length(); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item != null) addMessage(item.optString("role").equals("assistant") ? "JARVIS" : "SİZ", item.optString("content"));
        }
    }

    private void saveHistory() { prefs.edit().putString("history", history.toString()).apply(); }

    private void clearChat() {
        history = new JSONArray();
        messages.removeAllViews();
        saveHistory();
        addMessage("JARVIS", "Sohbet geçmişi temizlendi.");
    }

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        addMessage("SİZ", text);
        addHistory("user", text);
        if (handleLocalCommand(text)) return;
        status.setText("YANIT HAZIRLANIYOR...");
        new Thread(() -> {
            String answer = callBackend();
            runOnUiThread(() -> {
                status.setText("PERSONAL AI SYSTEM  •  ONLINE");
                addMessage("JARVIS", answer);
                addHistory("assistant", answer);
                if (speakReplies && tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
            });
        }).start();
    }

    private void addHistory(String role, String content) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("role", role);
            obj.put("content", content);
            history.put(obj);
            while (history.length() > 30) {
                JSONArray trimmed = new JSONArray();
                for (int i = history.length() - 30; i < history.length(); i++) trimmed.put(history.get(i));
                history = trimmed;
            }
            saveHistory();
        } catch (Exception ignored) {}
    }

    private boolean handleLocalCommand(String text) {
        String q = text.toLowerCase(new Locale("tr", "TR"));
        if (q.contains("ayarları aç") || q.contains("telefon ayarları")) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
            catch (Exception e) { addMessage("JARVIS", "Ayarlar açılamadı."); }
            return true;
        }
        if (q.contains("saat kaç") || q.equals("saat")) {
            String now = new java.text.SimpleDateFormat("HH:mm, dd.MM.yyyy", new Locale("tr", "TR")).format(new Date());
            addMessage("JARVIS", "Şu an " + now + ".");
            addHistory("assistant", "Şu an " + now + ".");
            return true;
        }
        if (q.startsWith("youtube aç")) return launchPackage("com.google.android.youtube", "YouTube");
        if (q.startsWith("whatsapp aç")) return launchPackage("com.whatsapp", "WhatsApp");
        if (q.startsWith("kamera aç")) {
            try { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
            catch (Exception e) { addMessage("JARVIS", "Kamera açılamadı."); }
            return true;
        }
        return false;
    }

    private boolean launchPackage(String pkg, String name) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) startActivity(launch);
        else addMessage("JARVIS", name + " bu telefonda bulunamadı.");
        return true;
    }

    private String callBackend() {
        HttpURLConnection conn = null;
        try {
            if (API_URL.contains("YOUR-SERVER")) return "Sunucu henüz bağlanmadı. Önce backend klasöründeki sunucuyu kurup MainActivity.java içindeki API_URL adresini değiştir.";
            URL url = new URL(API_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            JSONObject body = new JSONObject();
            body.put("messages", history);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            InputStream stream = conn.getResponseCode() >= 200 && conn.getResponseCode() < 300
                    ? conn.getInputStream() : conn.getErrorStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) result.append(line);
            JSONObject json = new JSONObject(result.toString());
            if (conn.getResponseCode() < 200 || conn.getResponseCode() >= 300)
                return "Sunucu hatası: " + json.optString("error", result.toString());
            return json.optString("reply", "Yanıt alınamadı.");
        } catch (Exception e) {
            return "Bağlantı kurulamadı: " + e.getMessage();
        } finally { if (conn != null) conn.disconnect(); }
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
            return;
        }
        launchSpeech();
    }

    private void launchSpeech() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS sizi dinliyor...");
        try { startActivityForResult(intent, SPEECH_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "Ses tanıma hizmeti bulunamadı.", Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_PERMISSION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) launchSpeech();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) { input.setText(matches.get(0)); sendMessage(); }
        }
    }

    @Override public void onInit(int result) {
        if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("tr", "TR"));
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
